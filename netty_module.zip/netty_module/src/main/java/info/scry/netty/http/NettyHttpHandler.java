package info.scry.netty.http;

import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

@ChannelHandler.Sharable
public class NettyHttpHandler extends ChannelInboundHandlerAdapter {
	private NettyHttp nettyHttp;

	public NettyHttpHandler(NettyHttp nettyHttp) {
		this.nettyHttp = nettyHttp;
	}

	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
		nettyHttp.handler(ctx, msg);
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		nettyHttp.exception(ctx, cause);
	}

}
