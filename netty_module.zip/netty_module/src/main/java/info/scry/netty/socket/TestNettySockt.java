package info.scry.netty.socket;

import io.netty.channel.ChannelHandlerContext;

public class TestNettySockt implements NettyHandler {
	@Override
	public void channelActive(ChannelHandlerContext ctx) {
		System.err.println("netty Tcp start!");
	}

	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) {
		CustomProtocol cp = (CustomProtocol) msg;

		try {
//			C2S_Gate_Heart cl = C2S_Gate_Heart.parseFrom(cp.getContent());
//			System.err.println(cl.getUserid() + "  :  " + cl.getPswd());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		ctx.writeAndFlush(cp);
//		ByteBuf bb = (ByteBuf) msg;
//		
//		bb.resetReaderIndex();
//		System.err.println("1------------------: " + bb.readIntLE());
//		Optional.ofNullable(bb).ifPresent(b -> {
//			byte[] tmp = new byte[b.readableBytes()];
//			b.readBytes(tmp);
//
//			System.err.println(new String(tmp));
//		});
//		bb.resetReaderIndex();
//		System.err.println("2------------------: " + bb.readInt());
//		Optional.ofNullable(bb).ifPresent(b -> {
//			byte[] tmp = new byte[b.readableBytes()];
//			b.readBytes(tmp);
//
//			System.err.println(new String(tmp));
//		});
//
//		bb.release();

		try {
//			Packet.packet packet = (Packet.packet) msg;
//			System.err.println("type : " + packet.getMsgId());
//			LoginPacket.C2S_Login c2SLogin = LoginPacket.C2S_Login.getDefaultInstance().parseFrom(packet.getData());
//			System.err.println("uid: " + c2SLogin.getUserid());
//			System.err.println("pwd: " + c2SLogin.getPswd());
//			ctx.writeAndFlush(msg);

//			LoginPacket.S2C_Login.Builder c2s = LoginPacket.S2C_Login.newBuilder();
//			Packet.packet.Builder builder = Packet.packet.newBuilder();
//			builder.setType(1);
//			c2s.setSuccess(1);
//			builder.setS2CLogin(c2s);
//			ctx.writeAndFlush(builder);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
		System.err.println("exception  :" + ctx + "   ex: " + cause);
	}

	@Override
	public void channelInactive(ChannelHandlerContext ctx) {
		System.err.println("close :" + ctx);
	}
}
