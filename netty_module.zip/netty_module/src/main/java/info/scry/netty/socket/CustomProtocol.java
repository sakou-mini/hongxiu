package info.scry.netty.socket;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CustomProtocol implements Serializable {
	private short opCode;
	private byte[] content;
}
