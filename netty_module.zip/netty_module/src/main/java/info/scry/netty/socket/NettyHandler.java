package info.scry.netty.socket;

import io.netty.channel.ChannelHandlerContext;

public interface NettyHandler {
	void channelActive(ChannelHandlerContext ctx);

	void channelRead(ChannelHandlerContext ctx, Object msg);

	void exceptionCaught(ChannelHandlerContext ctx, Throwable cause);

	void channelInactive(ChannelHandlerContext ctx);
}
