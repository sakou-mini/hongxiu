package info.scry.netty.socket;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

public class CustomProtocolEncoder extends MessageToByteEncoder<CustomProtocol> {

	@Override
	protected void encode(ChannelHandlerContext ctx, CustomProtocol msg, ByteBuf out) throws Exception {
		// TODO Auto-generated method stub
		// 1.写入消息的长度(short 类型)
		out.writeIntLE(msg.getContent().length + 2);//写到包头，包头长度改为了int，opcode改为short,因此+2
		// 2.写入消息msgid
		out.writeShortLE(msg.getOpCode());
		// 3.写入消息的内容(byte[]类型)
		out.writeBytes(msg.getContent());
	}

}
