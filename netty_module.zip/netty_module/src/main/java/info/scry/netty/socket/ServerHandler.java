package info.scry.netty.socket;

import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

@ChannelHandler.Sharable
public class ServerHandler extends ChannelInboundHandlerAdapter {

	private NettyHandler nettyHandler;

	public ServerHandler(NettyHandler handlerd) {
		this.nettyHandler = handlerd;
	}

	@Override
	public void channelActive(ChannelHandlerContext ctx) throws Exception {
		// TODO Auto-generated method stub
		nettyHandler.channelActive(ctx);
	}

	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) { 
		nettyHandler.channelRead(ctx, msg);
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) { 
		// Close the connection when an exception is raised.
		nettyHandler.exceptionCaught(ctx, cause);
//		cause.printStackTrace();
//		ctx.close();
	}

	@Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception {
		// TODO Auto-generated method stub
//		super.channelInactive(ctx);
		nettyHandler.channelInactive(ctx);
	}
}
