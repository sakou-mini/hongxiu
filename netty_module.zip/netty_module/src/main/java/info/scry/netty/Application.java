package info.scry.netty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import info.scry.common.context.SpringApplicationContext;
import info.scry.netty.socket.Server;
import info.scry.netty.socket.TestNettySockt;

@ComponentScan(value = "info.scry.common")
@ComponentScan(value = "info.scry.netty")
@SpringBootApplication
public class Application {
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		Server bean = SpringApplicationContext.getBean(Server.class);
		bean.bind(new TestNettySockt(), 8565);
	}
}
