package info.scry.netty.http;

import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.http.HttpContentCompressor;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpRequestDecoder;
import io.netty.handler.codec.http.HttpResponseEncoder;

public class HttpServerInitializer extends ChannelInitializer<SocketChannel> {
	private NettyHttp nettyHttp;

	public HttpServerInitializer(NettyHttp nettyHttp) {
		this.nettyHttp = nettyHttp;
	}

	@Override
	protected void initChannel(SocketChannel ch) throws Exception {
		// TODO Auto-generated method stub
		ChannelPipeline pipeline = ch.pipeline();
		// http服务器端对request解码
		pipeline.addLast("decoder", new HttpRequestDecoder());
		// http服务器端对response编码
		pipeline.addLast("encoder", new HttpResponseEncoder());
		// 拆包处理
		pipeline.addLast("aggregator", new HttpObjectAggregator(512 * 1024));
		/**
		 * Compresses an HttpMessage and an HttpContent in gzip or deflate encoding
		 * while respecting the "Accept-Encoding" header. If there is no matching
		 * encoding, no compression is done.
		 */
		pipeline.addLast("deflater", new HttpContentCompressor());
		// http handler
		pipeline.addLast("handler", new NettyHttpHandler(nettyHttp));
	}

}
