package info.scry.netty.http;

import io.netty.channel.ChannelHandlerContext;

public interface NettyHttp {
    void handler(ChannelHandlerContext ctx, Object msg);
    void exception(ChannelHandlerContext ctx, Throwable cause);
}
