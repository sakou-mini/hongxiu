package info.scry.netty.socket;

import java.util.concurrent.TimeUnit;

import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.timeout.IdleStateHandler;

public class ServerInitializer extends ChannelInitializer<SocketChannel> {

	private NettyHandler nettyHandle;

	public ServerInitializer(NettyHandler nettyHandle) {
		this.nettyHandle = nettyHandle;
	}

	@Override
	protected void initChannel(SocketChannel ch) throws Exception {
		// TODO Auto-generated method stub
		ChannelPipeline pipeline = ch.pipeline();

		pipeline.addLast("frameDecoder", new CustomProtocolDecoder());// 解码
		pipeline.addLast("frameEncoder", new CustomProtocolEncoder());// 编码

		pipeline.addLast("timeout", new IdleStateHandler(15, 0, 0, TimeUnit.MINUTES));// 添加心跳机制
		pipeline.addLast("handler", new ServerHandler(nettyHandle));// 自己定义的消息处理器，接收消息会在这个类处理
		pipeline.addLast(new HeartBeatServerHandler());// 心跳处理handle
	}

}