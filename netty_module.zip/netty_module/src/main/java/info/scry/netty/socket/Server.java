package info.scry.netty.socket;

import org.springframework.stereotype.Service;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;

@Service
public class Server {
    public void bind(NettyHandler nettyHandle,int port) {
    	//默认CPU的核数*２
        EventLoopGroup bossGroup = new NioEventLoopGroup();
        EventLoopGroup workerGroup = new NioEventLoopGroup(); 
        try {
			ServerBootstrap b = new ServerBootstrap();  
		      b.group(bossGroup,workerGroup).channel(NioServerSocketChannel.class)
			  .option(ChannelOption.SO_BACKLOG, 128)
	          .option(ChannelOption.SO_RCVBUF, 1024 * 256) 
			  .option(ChannelOption.SO_REUSEADDR, true) //重用地址
	          .childOption(ChannelOption.SO_SNDBUF, 1024 * 256) 
			  .childOption(ChannelOption.TCP_NODELAY, true)
			  .childOption(ChannelOption.SO_KEEPALIVE, true)
			  .childOption(ChannelOption.ALLOCATOR, new PooledByteBufAllocator(false))  // 不使用堆内存
			  .childHandler(new ServerInitializer(nettyHandle));
			// Bind and start to accept incoming connections.
		      ChannelFuture f = b.bind(port).sync();  

			// Wait until the server socket is closed.
			// In this example, this does not happen, but you can do that to gracefully
			// shut down your server.
            System.err.println("start server success on port " + port);
			f.channel().closeFuture().sync();
        }catch (Exception e){
            System.err.println("start server failed on port " + port);
            System.exit(-1);
        }finally {
            workerGroup.shutdownGracefully();
            bossGroup.shutdownGracefully();
        }
    }

    public void bind(NettyHandler nettyHandler){
        bind(nettyHandler,8080);
    }
    public static void main(String[] args) {
		new Server().bind(new TestNettySockt()); 
	}
}
