package info.scry.netty.socket;

import java.util.List;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

public class CustomProtocolDecoder extends ByteToMessageDecoder {
	public final int BASE_LENGTH = 2 + 4;

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buffer, List<Object> out) throws Exception {
		// TODO Auto-generated method stub
		// 可读长度必须大于基本长度
		if (buffer.readableBytes() >= BASE_LENGTH) {
			// 防止socket字节流攻击 ,客户端传来的数据过大是不合理的
			if (buffer.readableBytes() > 2048) {
				buffer.skipBytes(buffer.readableBytes());
			}

			while (true) {
				// 标记包头开始的index
				buffer.markReaderIndex();
				int len = buffer.readIntLE();
				if (len <= buffer.readableBytes()) {
					buffer.resetReaderIndex();
					break;
				}

				// 每次略过一个字节去读取包头信息的开始标记
				buffer.resetReaderIndex();
				buffer.readByte();

				// 当略过，一个字节之后，数据包的长度，又变得不满足,此时应该结束,等待后面的数据到达
				if (buffer.readableBytes() < BASE_LENGTH) {
					return;
				}
			}

			// 消息的长度（包含了opcode和消息体的长度）
			int length = buffer.readIntLE();
			// msg Id
			short msgId = buffer.readShortLE();

			// 读取data数据(减去opcode的长度就是数据包)
			byte[] data = new byte[length - 2];
			buffer.readBytes(data);

			// 生成
			CustomProtocol protocol = new CustomProtocol(msgId, data);
			out.add(protocol);
		}
	}

}
